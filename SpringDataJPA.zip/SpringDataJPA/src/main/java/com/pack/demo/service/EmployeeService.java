package com.pack.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.demo.model.Employee;
import com.pack.demo.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepository empRepo;
	

	public void addEmployee(Employee e) {
		// TODO Auto-generated method stub
		empRepo.save(e);
	}
	
	public List<Employee> viewAll ()
	{
		return empRepo.findAll();
	}

}
