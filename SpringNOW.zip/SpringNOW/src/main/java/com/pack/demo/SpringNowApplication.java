package com.pack.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringNowApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringNowApplication.class, args);
	}

}
