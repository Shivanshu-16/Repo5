package com.pack.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.pack.demo.model.Employee;
import com.pack.demo.service.EmployeeService;

@RestController
public class EmployeeController 
{
	@Autowired
	EmployeeService service;
	
	@PostMapping("/addEmployee")
	public void saveEmployee(@RequestBody Employee employee)
	{
		service.saveEmployee(employee);
	}
	
	@GetMapping("/employees")
	public List<Employee> Employees()
	{
		return service.getEmployees();
	}
	
	@GetMapping("/employee/{id}")
	public ResponseEntity<Employee> getEmpById (@PathVariable long id)
	{
		Employee emp=service.getEmployeeById(id);
		if(emp==null)
		{
			return new ResponseEntity<Employee>(emp,HttpStatus.NOT_FOUND);
		}
		else
		{
			return new ResponseEntity<Employee>(emp,HttpStatus.OK);
		}
	}
	
	
	@PutMapping("/employee/{id}")
	public ResponseEntity<Employee> updateEmployee (@RequestBody Employee employeeDetails,@PathVariable long id)
	{
		Employee emp=service.getEmployeeById(id);
		if(emp==null)
		{
			return new ResponseEntity<Employee>(emp,HttpStatus.NOT_FOUND);
		}
		else
		{
			emp.setName(employeeDetails.getName());
			emp.setDesignation(employeeDetails.getDesignation());
			emp.setSalary(employeeDetails.getSalary());
			emp.setInsScheme(employeeDetails.getInsScheme());
			service.saveEmployee(emp);
			return new ResponseEntity<Employee>(emp,HttpStatus.OK);
		}
	}
	
	@DeleteMapping("/employee/{id}")
	public ResponseEntity<Object> deleteEmployee (@PathVariable int id)
	{
		Employee emp= service.getEmployeeById(id);
		if(emp==null)
		{
			return ResponseEntity.notFound().build();
		}
		else
		{
			service.removeProduct(emp);
			return ResponseEntity.ok().build();
		}
	}
	
}
