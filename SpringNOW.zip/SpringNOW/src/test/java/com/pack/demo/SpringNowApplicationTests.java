package com.pack.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringNowApplicationTests {

	@Test
	void contextLoads() {
	}

}
